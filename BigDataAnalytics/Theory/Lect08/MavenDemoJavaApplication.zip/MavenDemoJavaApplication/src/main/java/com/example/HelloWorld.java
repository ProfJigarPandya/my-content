package com.example;
public class HelloWorld
{
	public static void main(String args[])
	{
		System.out.println("Hello World of Java.");
		System.out.println("Demonstrating simple maven build...");
	}
}
