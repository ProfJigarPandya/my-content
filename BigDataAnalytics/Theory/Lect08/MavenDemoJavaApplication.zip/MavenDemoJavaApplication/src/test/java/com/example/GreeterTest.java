import org.junit.*;
import static org.junit.Assert.*;
import com.example.Greeter;
public class GreeterTest
{
	private Greeter greeter = new Greeter();
	@Test
	public void greeterSayHello()
	{
		assertEquals("Testing the Hello TDD message.","Hello TDD - Test Driven Development",greeter.sayHello());
	}
}
