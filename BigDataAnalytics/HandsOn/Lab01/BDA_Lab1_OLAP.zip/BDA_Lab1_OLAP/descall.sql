desc JD_Branch_ADM;
desc JD_Fellow_ADM;
desc JD_Duration_ADM;
desc JF_ADM;

