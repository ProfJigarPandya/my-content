drop table JF_ADM;
drop table JD_Branch_ADM;
drop table JD_Fellow_ADM;
drop table JD_Duration_ADM;
