Select * from JD_Branch_ADM;
Select * from JD_Fellow_ADM;
Select * from JD_Period_ADM;
Select * from JF_ADM;

