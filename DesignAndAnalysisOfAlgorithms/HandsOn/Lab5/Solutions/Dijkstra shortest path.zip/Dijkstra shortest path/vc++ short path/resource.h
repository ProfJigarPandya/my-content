//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DSP.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_DSPTYPE                     129
#define IDD_SELECT_SD_DLG               130
#define IDD_NAMEOFCITY                  131
#define IDD_DISTBETCITY                 132
#define IDC_CURSOR_CITY                 132
#define IDC_CURSOR_SS                   133
#define IDC_CURSOR_SD                   134
#define IDB_BITMAP1                     136
#define IDB_BITMAP2                     137
#define IDC_SOURCE_CITY_DB              1000
#define IDC_NAMEOFCITY                  1003
#define IDC_DISTANCE                    1006
#define IDC_DEST_CITY_CB                1006
#define IDC_SEARCH                      1007
#define IDC_XYZ                         1008
#define IDC_SEARCH_TEXT                 1009
#define ID_ADD_CITY                     32771
#define ID_ADD_ROAD                     32772
#define ID_BUTTON32776                  32776
#define ID_BUTTON32778                  32778
#define ID_BUTTON32779                  32779
#define ID_BUTTON32780                  32780
#define ID_BUTTON32781                  32781
#define ID_BUTTON32782                  32782
#define ID_BUTTON32783                  32783
#define ID_BUTTON32784                  32784
#define ID_BUTTON32785                  32785
#define ID_BUTTON32786                  32786
#define ID_BUTTON32787                  32787
#define ID_BUTTON32788                  32788

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        144
#define _APS_NEXT_COMMAND_VALUE         32789
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
